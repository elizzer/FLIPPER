display_manager/display_manager.o: display_manager/display_manager.c \
 display_manager/display_manager.h
display_manager/display_manager.h:
