shapes/shapes.o: shapes/shapes.c shapes/shapes.h
shapes/shapes.h:
