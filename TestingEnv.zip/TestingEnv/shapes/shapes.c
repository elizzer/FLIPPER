#include "shapes.h"
#include <stddef.h>
#include <stdio.h>

draw_func_t draw_pixel = NULL;

static int8_t validate_draw_pixel()
{
    if (draw_pixel == NULL)
    {
        return -1; // Error: draw_pixel function pointer is not set
    }
    return 0; // Success
}

int8_t shape_init(draw_func_t draw_pixel_func)
{
    if (draw_pixel_func == NULL)
    {
        return -1; // Error: draw_pixel_func is NULL
    }
    draw_pixel = draw_pixel_func;
    return 0; // Success
}

int8_t draw_horizontal_line(int x1, int x2, int y, uint16_t color)
{
    // return validate_draw_pixel() == 0 ? 0 : -1;
    int8_t result = validate_draw_pixel();
    if (result != 0)
    {
        printf("Error: draw_pixel function pointer is not set\n");
        return -1; // Error: draw_pixel function pointer is not set
    }
    if (x1 > x2)
    {
        int temp = x1;
        x1 = x2;
        x2 = temp;
    }
    for (int x = x1; x <= x2; x++)
    {
        draw_pixel(x, y, color);
    }
    return 0;
}
int8_t draw_vertical_line(int x, int y1, int y2, uint16_t color)
{
    int8_t result = validate_draw_pixel();
    if (result != 0)
    {
        printf("Error: draw_pixel function pointer is not set\n");
        return -1; // Error: draw_pixel function pointer is not set
    }
    if (y1 > y2)
    {
        int temp = y1;
        y1 = y2;
        y2 = temp;
    }
    for (int y = y1; y <= y2; y++)
    {
        draw_pixel(x, y, color);
    }
    return 0;
}
// int8_t draw_line(int x1, int y1, int x2, int y2, uint16_t color);
int8_t draw_rectangle(int x, int y, int width, int height, uint16_t color)
{
    // return validate_draw_pixel() == 0 ? 0 : -1;
    // printf("Drawing rectangle at x=%d, y=%d, width=%d, height=%d\n", x, y, width, height);
    // printf("Drawing horizontal line from (%d, %d) to (%d, %d)\n", x, y, x + width - 1, y);
    draw_horizontal_line(x, x + width - 1, y, color);
    // printf("Drawing horizontal line from (%d, %d) to (%d, %d)\n", x, y + height - 1, x + width - 1, y + height - 1);
    draw_horizontal_line(x, x + width - 1, y + height - 1, color);
    // printf("Drawing vertical line from (%d, %d) to (%d, %d)\n", x, y, x, y + height - 1);
    draw_vertical_line(x, y, y + height - 1, color);
    // printf("Drawing vertical line from (%d, %d) to (%d, %d)\n", x + width - 1, y, x + width - 1, y + height - 1);
    draw_vertical_line(x + width - 1, y, y + height - 1, color);
    return 0;
}
// int8_t draw_filled_rectangle(int x, int y, int width, int height, uint16_t color){

// }
// int8_t draw_circle(int x_center, int y_center, int radius, uint16_t color);
// int8_t draw_filled_circle(int x_center, int y_center, int radius, uint16_t color);

int8_t shape_deinit()
{
    draw_pixel = NULL;
    return 0; // Success
}