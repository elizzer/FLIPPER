#include <stdio.h>
#include <stdint.h>

#include "display_manager.h"
#include "shapes.h"

#define WIDTH 240
#define HEIGHT 320

// display buffer (32-bit per pixel)
uint32_t display_buffer[WIDTH * HEIGHT];

displayHandle_t disp_handle;

void draw_pixel_wrapper(uint16_t x, uint16_t y, uint16_t color)
{
    int8_t ret = display_drawPixel(&disp_handle, x, y, color);
    if (ret != 0)
    {
        printf("Failed to draw pixel at (%d, %d)\n", x, y);
    }
}

void put_pixel(int x, int y, uint32_t color)
{
    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT)
        display_buffer[y * WIDTH + x] = color;
}

void render_disp_buffer(uint16_t *buf,
                        uint16_t x,
                        uint16_t y,
                        uint16_t width,
                        uint16_t height,
                        void *handle)
{

    printf("\nRender_displ_buffer");
    for (uint16_t row = 0; row < height; row++)
    {
        for (uint16_t col = 0; col < width; col++)
        {
            uint16_t src_pixel = buf[row * width + col];

            uint16_t dst_x = x + col;
            uint16_t dst_y = y + row;

            if (dst_x < WIDTH && dst_y < HEIGHT)
            {
                display_buffer[dst_y * WIDTH + dst_x] = src_pixel;
            }
        }
    }
}

void save_to_ppm(const char *filename)
{
    FILE *f = fopen(filename, "wb");

    if (!f)
    {
        printf("Failed to open file\n");
        return;
    }

    fprintf(f, "P6\n%d %d\n255\n", WIDTH, HEIGHT);

    for (int i = 0; i < WIDTH * HEIGHT; i++)
    {
        uint16_t pixel565 = display_buffer[i];

        uint8_t r5 = (pixel565 >> 11) & 0x1F;
        uint8_t g6 = (pixel565 >> 5) & 0x3F;
        uint8_t b5 = pixel565 & 0x1F;

        uint8_t r8 = (r5 << 3) | (r5 >> 2);
        uint8_t g8 = (g6 << 2) | (g6 >> 4);
        uint8_t b8 = (b5 << 3) | (b5 >> 2);

        fwrite(&r8, 1, 1, f);
        fwrite(&g8, 1, 1, f);
        fwrite(&b8, 1, 1, f);
    }

    fclose(f);
}

int main()
{
    printf("Rendering display buffer...\n");

    // render_gradient();

    displayConfig_t config = {
        .width = WIDTH,
        .height = HEIGHT,
        .frame_buffer = NULL, // cast to 16-bit buffer for testing
        .write_buffer_func = render_disp_buffer,
        .display_device_handle = &disp_handle};

    int8_t status = display_init(&config, &disp_handle);

    status = shape_init(draw_pixel_wrapper);
    if (status != 0)
    {
        printf("Failed to initialize shapes module\n");
        return;
    }

    // draw few rectangle
    printf("\n\n\nDrawing rectangles on the display\n");
    status = draw_rectangle(50, 50, 100, 150, 0xF800);
    if (status != 0)
    {
        printf("Failed to draw rectangle\n");
    }
    display_writeBuffer(&disp_handle);

    draw_rectangle(70, 70, 60, 110, 0x07E0);
    display_writeBuffer(&disp_handle);

    draw_rectangle(90, 90, 20, 70, 0x001F);
    display_writeBuffer(&disp_handle);

    draw_rectangle(110, 110, 10, 30, 0xFFE0);
    display_writeBuffer(&disp_handle);

    draw_rectangle(120, 120, 5, 15, 0xF81F);
    display_writeBuffer(&disp_handle);

    //

    display_deinit(&disp_handle);

    printf("Saving to image.ppm...\n");

    save_to_ppm("image.ppm");

    printf("Done. Open image.ppm to see result.\n");

    return 0;
}