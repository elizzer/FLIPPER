test.o: test.c display_manager/display_manager.h shapes/shapes.h
display_manager/display_manager.h:
shapes/shapes.h:
