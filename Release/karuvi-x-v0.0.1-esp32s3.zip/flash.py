#!/usr/bin/env python3
"""
Karuvi X - ESP32-S3 flash script

Works with either release layout, auto-detected:
  - Three files: bootloader*.bin, partition*.bin, and the app .bin
  - One merged .bin (built with `esptool merge_bin`)

Usage:
    python3 flash.py                 (auto-detect port)
    python3 flash.py /dev/ttyUSB0    (specify port manually, Linux/macOS)
    python3 flash.py COM3            (specify port manually, Windows)
"""

import glob
import os
import subprocess
import sys

CHIP = "esp32s3"
BAUD = "115200"  # conservative default - avoids write corruption on cheap USB-serial chips/cables

BOOTLOADER_OFFSET = "0x0"
PARTITION_OFFSET = "0x8000"
APP_OFFSET = "0x10000"
MERGED_OFFSET = "0x0"


def ensure_esptool():
    try:
        import esptool  # noqa: F401
        return
    except ImportError:
        pass
    print("esptool not found - installing it now...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--user", "esptool"]
    )
    if result.returncode != 0:
        sys.exit(
            "\n[ERROR] Could not install esptool automatically.\n"
            "Try manually: python3 -m pip install esptool"
        )
    print()


def find_flash_plan():
    """Return a list of (offset, path) pairs to pass to write_flash."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    bins = sorted(glob.glob(os.path.join(script_dir, "*.bin")))

    if not bins:
        sys.exit(
            "[ERROR] No .bin file found in this folder.\n"
            "Make sure flash.py sits next to the .bin file(s) from the release."
        )

    bootloader = [b for b in bins if "bootloader" in os.path.basename(b).lower()]
    partition = [b for b in bins if "partition" in os.path.basename(b).lower()]
    remaining = [b for b in bins if b not in bootloader and b not in partition]

    # Three-file layout: bootloader.bin + partition-table.bin + app.bin
    if bootloader and partition and len(remaining) == 1:
        print("Detected 3-file release: bootloader + partition table + app\n")
        return [
            (BOOTLOADER_OFFSET, bootloader[0]),
            (PARTITION_OFFSET, partition[0]),
            (APP_OFFSET, remaining[0]),
        ]

    # Single merged binary
    if len(bins) == 1:
        print("Detected single merged binary\n")
        return [(MERGED_OFFSET, bins[0])]

    # Ambiguous - let the user pick a single merged file, or bail with guidance
    print("Multiple .bin files found and they don't match the expected")
    print("bootloader / partition-table / app naming. Choose the merged file to flash,")
    print("or fix the folder to contain either one merged .bin, or exactly")
    print("bootloader*.bin + partition*.bin + one app .bin:\n")
    for i, b in enumerate(bins, 1):
        print(f"  {i}. {os.path.basename(b)}")
    while True:
        choice = input(f"Choose a file [1-{len(bins)}]: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(bins):
            return [(MERGED_OFFSET, bins[int(choice) - 1])]
        print("Invalid choice, try again.")


def main():
    print("==================================")
    print(" Karuvi X - ESP32-S3 Flasher")
    print("==================================\n")

    ensure_esptool()
    plan = find_flash_plan()
    for offset, path in plan:
        print(f"  {offset}  ->  {os.path.basename(path)}")
    print()

    port = sys.argv[1] if len(sys.argv) > 1 else None
    port_args = ["--port", port] if port else []
    base_cmd = [sys.executable, "-m", "esptool", "--chip", CHIP] + port_args

    print("Erasing flash first (clears any old firmware/settings) ...")
    print("(If this hangs, hold the BOOT button on your board and try again.)\n")
    erase_result = subprocess.run(base_cmd + ["--baud", BAUD, "erase_flash"])
    if erase_result.returncode != 0:
        sys.exit(
            "\n[ERROR] Erase failed - could not talk to the board.\n"
            "  - Hold BOOT while plugging in, or while running this script\n"
            "  - Check USB cable/driver (CP210x or CH340/CH9102)\n"
            "  - Try specifying the port manually:\n"
            "      python3 flash.py /dev/ttyUSB0   (Linux/macOS)\n"
            "      python3 flash.py COM3           (Windows)"
        )

    print("\nFlashing to ESP32-S3 ...\n")
    write_args = []
    for offset, path in plan:
        write_args += [offset, path]
    result = subprocess.run(
        base_cmd + ["--baud", BAUD, "write_flash"] + write_args
    )

    if result.returncode == 0:
        print("\nDone! Your board should restart automatically.")
    else:
        print(
            "\n[ERROR] Flashing failed. Things to check:\n"
            "  - USB cable is a data cable, not charge-only\n"
            "  - USB driver installed (CP210x or CH340/CH9102 depending on your board)\n"
            "  - Try specifying the port manually:\n"
            "      python3 flash.py /dev/ttyUSB0   (Linux/macOS)\n"
            "      python3 flash.py COM3           (Windows)"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()